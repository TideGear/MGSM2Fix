Optional testing aids for the MGSM2Fix upstream PR series.
Built from source with retail-byte assertions; gameplay verification remains open.
These patches are separate from the English/grenade distribution.
See PR 7 and the scripts for supported discs, configuration and removal instructions.
No patches were deployed during this build.
